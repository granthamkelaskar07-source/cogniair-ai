const API = import.meta.env.VITE_API_URL || "http://localhost:8000/api";
export async function request(path: string, body?: unknown) {
  const res = await fetch(`${API}${path}`, {method: body ? "POST" : "GET", headers: {"Content-Type":"application/json"}, body: body ? JSON.stringify(body) : undefined});
  if (!res.ok) { const err = await res.json().catch(()=>({detail:"Request failed"})); throw new Error(err.detail || "Request failed"); }
  return res.json();
}
