from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.routes import router

app = FastAPI(title="CogniAir-AI API", version="1.0.0", description="Predictive indoor CO₂ simulation and ventilation guidance")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.include_router(router, prefix="/api")

@app.get("/")
def root():
    return {"name": "CogniAir-AI", "status": "running", "docs": "/docs"}
