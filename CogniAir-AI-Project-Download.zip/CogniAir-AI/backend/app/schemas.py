from pydantic import BaseModel, Field
from typing import Literal

class Thresholds(BaseModel):
    good_max: float = Field(800, gt=0)
    moderate_max: float = Field(1000, gt=0)
    elevated_max: float = Field(1500, gt=0)

class RoomInput(BaseModel):
    room_name: str = "My Room"
    length_m: float = Field(8, gt=0, le=200)
    width_m: float = Field(6, gt=0, le=200)
    height_m: float = Field(3, gt=0, le=20)
    occupants: int = Field(18, ge=0, le=1000)
    duration_minutes: int = Field(120, ge=5, le=1440)
    initial_co2_ppm: float = Field(650, ge=300, le=10000)
    outdoor_co2_ppm: float = Field(420, ge=300, le=2000)
    ventilation_m3_h: float = Field(180, ge=0, le=100000)
    generation_l_h_person: float = Field(18, gt=0, le=100)
    thresholds: Thresholds = Thresholds()

class ForecastInput(BaseModel):
    current_co2_ppm: float = Field(650, ge=300, le=10000)
    occupants: int = Field(18, ge=0, le=1000)
    room_volume_m3: float = Field(144, gt=0)
    ventilation_m3_h: float = Field(180, ge=0)
    outdoor_co2_ppm: float = 420
    horizon_minutes: int = Field(60, ge=15, le=240)
    generation_l_h_person: float = 18
    time_of_day_hour: int = Field(10, ge=0, le=23)
