from pathlib import Path
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error
import joblib
from app.schemas import ForecastInput

MODEL_PATH = Path(__file__).with_name("model.joblib")

def _train():
    rng = np.random.default_rng(17)
    n = 3500
    current = rng.uniform(450, 1800, n)
    occ = rng.integers(0, 45, n)
    volume = rng.uniform(60, 900, n)
    vent = rng.uniform(0, 1500, n)
    outdoor = rng.uniform(390, 500, n)
    gen = rng.uniform(12, 24, n)
    horizon = rng.choice([15, 30, 45, 60, 90, 120], n)
    # Synthetic targets use the same well-mixed mass balance approximation.
    q = vent / 60
    g = gen / 1000 / 60
    rate = (g * occ / volume) * 1e6 - (q / volume) * (current - outdoor)
    target = np.maximum(300, current + rate * horizon * 0.72 + rng.normal(0, 18, n))
    X = np.column_stack([current, occ, volume, vent, outdoor, gen, horizon])
    xtr, xte, ytr, yte = train_test_split(X, target, test_size=.2, random_state=42)
    model = RandomForestRegressor(n_estimators=100, max_depth=14, random_state=42, n_jobs=-1)
    model.fit(xtr, ytr)
    pred = model.predict(xte)
    joblib.dump(model, MODEL_PATH)
    return model, {"mae_ppm": round(float(mean_absolute_error(yte, pred)), 2), "rmse_ppm": round(float(np.sqrt(mean_squared_error(yte, pred))), 2), "training_data": "synthetic"}

def train_model():
    _, metrics = _train()
    return {"status": "trained", **metrics}

def forecast(p: ForecastInput):
    if MODEL_PATH.exists():
        model = joblib.load(MODEL_PATH)
        model_source = "synthetic_demo_model"
    else:
        model, _ = _train()
        model_source = "synthetic_demo_model"
    horizons = list(range(15, p.horizon_minutes + 1, 15))
    if not horizons or horizons[-1] != p.horizon_minutes:
        horizons.append(p.horizon_minutes)
    rows = []
    for h in horizons:
        x = np.array([[p.current_co2_ppm, p.occupants, p.room_volume_m3, p.ventilation_m3_h, p.outdoor_co2_ppm, p.generation_l_h_person, h]])
        rows.append({"minute": h, "predicted_co2_ppm": round(float(model.predict(x)[0]), 1)})
    return {"forecast": rows, "model": model_source, "data_source": "synthetic-trained ML demonstration; calibrate with real sensor data before operational use"}
