from fastapi import APIRouter, HTTPException
from app.schemas import RoomInput, ForecastInput, Thresholds
from app.services.simulation import simulate
from app.services.guidance import assess
from app.ml.predictor import forecast
from app.database import init_db, save_room, list_rooms, save_alert, list_alerts

router = APIRouter()
init_db()

@router.get("/health")
def health():
    return {"status": "ok"}

@router.post("/simulation/run")
def run_simulation(payload: RoomInput):
    try:
        result = simulate(payload)
        result["guidance"] = assess(result["series"], payload.thresholds)
        if result["guidance"]["severity"] != "good":
            save_alert(payload.room_name, result["guidance"])
        return result
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@router.post("/prediction/forecast")
def predict(payload: ForecastInput):
    return forecast(payload)

@router.get("/dashboard/metrics")
def dashboard_metrics():
    demo = RoomInput(room_name="Demo Classroom", length_m=8, width_m=6, height_m=3, occupants=18, duration_minutes=120, initial_co2_ppm=650, outdoor_co2_ppm=420, ventilation_m3_h=180, generation_l_h_person=18)
    result = simulate(demo)
    return {"source": "simulated_demo", "room": demo.room_name, "current_co2_ppm": result["series"][0]["co2_ppm"], "predicted_co2_ppm": result["series"][-1]["co2_ppm"], "occupants": demo.occupants, "ventilation_m3_h": demo.ventilation_m3_h, "guidance": assess(result["series"], demo.thresholds)}

@router.get("/rooms")
def rooms():
    return list_rooms()

@router.post("/rooms")
def create_room(payload: RoomInput):
    return save_room(payload.model_dump())

@router.get("/alerts")
def alerts():
    return list_alerts()

@router.get("/analytics")
def analytics():
    return {"message": "Analytics are generated from simulation and prediction runs. Use /simulation/run to create a scenario.", "data_source": "simulated_or_user_supplied"}
