import sqlite3, json
from pathlib import Path
DB = Path(__file__).resolve().parents[1] / "cogniair.db"

def conn():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row; return c

def init_db():
    with conn() as c:
        c.execute("CREATE TABLE IF NOT EXISTS rooms (id INTEGER PRIMARY KEY, room_name TEXT, config TEXT)")
        c.execute("CREATE TABLE IF NOT EXISTS alerts (id INTEGER PRIMARY KEY, room_name TEXT, severity TEXT, message TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)")

def save_room(data):
    with conn() as c:
        cur = c.execute("INSERT INTO rooms(room_name, config) VALUES (?,?)", (data["room_name"], json.dumps(data)))
        return {"id": cur.lastrowid, "room_name": data["room_name"], "saved": True}

def list_rooms():
    with conn() as c:
        return [{"id": r["id"], "room_name": r["room_name"], "config": json.loads(r["config"])} for r in c.execute("SELECT * FROM rooms ORDER BY id DESC")]

def save_alert(room, guidance):
    with conn() as c:
        c.execute("INSERT INTO alerts(room_name,severity,message) VALUES (?,?,?)", (room, guidance["severity"], guidance["action"]))

def list_alerts():
    with conn() as c:
        return [dict(r) for r in c.execute("SELECT * FROM alerts ORDER BY id DESC LIMIT 50")]
