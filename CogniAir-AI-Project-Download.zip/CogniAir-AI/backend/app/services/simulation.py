import math
from app.schemas import RoomInput

def simulate(p: RoomInput, step_minutes: int = 5):
    volume = p.length_m * p.width_m * p.height_m
    q_m3_min = p.ventilation_m3_h / 60.0
    # G is converted from litres CO₂/hour/person to m³ CO₂/minute/person.
    generation_m3_min = p.generation_l_h_person / 1000.0 / 60.0
    c = float(p.initial_co2_ppm)
    series = []
    steps = math.ceil(p.duration_minutes / step_minutes)
    for i in range(steps + 1):
        minute = min(i * step_minutes, p.duration_minutes)
        series.append({"minute": minute, "co2_ppm": round(c, 1)})
        if minute >= p.duration_minutes:
            break
        # dC/dt in ppm/min. Explicit Euler integration of the well-mixed mass balance.
        dc_dt = (generation_m3_min * p.occupants / volume) * 1_000_000 - (q_m3_min / volume) * (c - p.outdoor_co2_ppm)
        c = max(0, c + dc_dt * step_minutes)
    crossed = next((x["minute"] for x in series if x["co2_ppm"] >= p.thresholds.elevated_max), None)
    return {"room_name": p.room_name, "room_volume_m3": round(volume, 2), "duration_minutes": p.duration_minutes, "step_minutes": step_minutes, "series": series, "final_co2_ppm": series[-1]["co2_ppm"], "time_to_elevated_threshold_minutes": crossed, "data_source": "physics_simulation"}
