def assess(series, thresholds):
    value = series[-1]["co2_ppm"] if series else 0
    if value <= thresholds.good_max:
        severity, title, action = "good", "Air status is within the configured good band", "Continue monitoring and maintain the current ventilation setting."
    elif value <= thresholds.moderate_max:
        severity, title, action = "moderate", "CO₂ is above the configured good band", "Consider increasing outdoor-air ventilation if conditions permit."
    elif value <= thresholds.elevated_max:
        severity, title, action = "elevated", "CO₂ is elevated", "Increase outdoor-air ventilation; review occupancy and mechanical ventilation."
    else:
        severity, title, action = "high", "CO₂ is above the configured elevated threshold", "Act promptly: increase outdoor-air ventilation and reduce occupancy if ventilation capacity is insufficient."
    return {"severity": severity, "title": title, "action": action, "observed_co2_ppm": value, "basis": "configured CO₂ thresholds; CO₂ alone does not represent all indoor air pollutants"}
