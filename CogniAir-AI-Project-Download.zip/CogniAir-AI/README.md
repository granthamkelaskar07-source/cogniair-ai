# CogniAir-AI — Predictive Indoor Air Quality Platform

A runnable starter implementation based on the uploaded project presentation: room/occupancy inputs, physics-based CO₂ mass-balance simulation, forecast chart, AI/ML prediction pipeline, smart ventilation guidance, and alerts.

## Requirements
- Python 3.10+
- Node.js 18+

## Run the backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
API docs: http://localhost:8000/docs

## Run the frontend
In a second terminal:
```bash
cd frontend
npm install
npm run dev
```
Open the URL printed by Vite (normally http://localhost:5173).

## Notes
- Demo data is explicitly labeled simulated. No real sensor feed is assumed.
- The default CO₂ bands are configurable application defaults, not universal health/safety standards.
- The forecast model trains on generated synthetic examples when no trained model exists. Treat these predictions as a demonstration until calibrated with real, representative sensor data.
- CO₂ is not a complete measure of indoor air quality; particulate matter, VOCs, humidity, temperature, and ventilation context may also matter.
